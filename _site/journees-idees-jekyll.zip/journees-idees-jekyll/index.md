---
layout: home
title: Journées IDEES
---

<div class="eyebrow">ÉDITION 2026 · ATELIER DE 2 JOURS</div>

# Journées IDEES

## IA pour le Développement, Entreprises et EnseignementS

Atelier de réflexion et de partage réunissant académiques et industriels autour de l'enseignement de l'informatique à l'ère des IA génératives.

<div class="hero-facts">
  <div><span class="fact-icon">▦</span><strong>Jeudi 17 &amp; vendredi 18 décembre</strong><small>Deux journées d'ateliers &amp; conférences</small></div>
  <div><span class="fact-icon">⌖</span><strong>Lieu à préciser</strong><small>Format présentiel avec buffet &amp; dîner</small></div>
  <div><span class="fact-icon">◎</span><strong>Académiques &amp; industriels</strong><small>Retours d'expérience, débats &amp; démos</small></div>
</div>

<div class="hero-actions">
  <a class="button button-primary" href="{{ '/programme/' | relative_url }}">Consulter le programme</a>
  <a class="button button-secondary" href="{{ '/objectifs/' | relative_url }}">En savoir plus</a>
</div>

---

<div class="section-kicker">CONTEXTE &amp; VISION</div>
# Pourquoi ces journées ?

L'arrivée fulgurante des assistants de codage et des modèles de langage transforme profondément les pratiques professionnelles des développeurs et des ingénieurs.

Le but de ces deux journées sera de mieux cerner ce qu'il faut adapter dans les enseignements compte tenu des nouvelles pratiques existantes, des besoins des entreprises et des compétences émergentes attendues chez les futurs diplômés.

<div class="card-grid three">
  <article class="card"><span class="number">01</span><h3>Confronter regards académiques et industriels</h3><p>Comprendre la réalité du déploiement de l'IA en entreprise : impact sur l'organisation du travail, intégration et montée en compétences des profils juniors.</p></article>
  <article class="card"><span class="number">02</span><h3>Redéfinir le rôle de l'informaticien</h3><p>Explorer la frontière entre informaticiens et experts métiers capables de développer leurs propres outils assistés par l'IA.</p></article>
  <article class="card"><span class="number">03</span><h3>Actualiser les cursus et contenus</h3><p>Identifier les concepts, outils et méthodologies à intégrer : harnais, skills, RAG, agents, Model Context Protocol (MCP), Spec-Driven Development, etc.</p></article>
</div>

<div class="section-kicker">AXES DE TRAVAIL</div>
# Deux grands thèmes d'échange

L'idée fondatrice est de réunir des enseignants, des chercheurs et des professionnels autour de deux problématiques complémentaires.

<div class="card-grid two">
  <article class="card topic-card"><div class="topic-icon">⌘</div><div class="muted">AXE 1</div><h3>Enseigner le développement à l'aide de l'IA</h3><p class="lead">Utiliser les assistants de codage dans l'apprentissage</p><ul><li>Comment intégrer les assistants de programmation (Copilot, Cursor, etc.) dans les travaux pratiques et projets ?</li><li>Quels nouveaux réflexes méthodologiques enseigner (revue critique de code, tests, prompting, spécification) ?</li><li>Évaluer les compétences des étudiants à l'heure des IA génératives.</li><li>Impact sur l'autonomie et l'apprentissage des fondamentaux de l'algorithmique.</li></ul></article>
  <article class="card topic-card"><div class="topic-icon">◇</div><div class="muted">AXE 2</div><h3>Enseigner le développement d'applications basées sur l'IA générative</h3><p class="lead">Construire avec les nouvelles architectures logicielles IA</p><ul><li>Architectures RAG (Retrieval-Augmented Generation) et bases vectorielles.</li><li>Agents autonomes, systèmes multi-agents et communication Agent-to-Agent (A2A).</li><li>Model Context Protocol (MCP), skills et tool-calling.</li><li>Harnais de test, Spec-Driven Development et ingénierie de prompt avancée.</li><li>Modèles locaux vs Cloud (LLM, SLM) et contraintes de souveraineté.</li></ul></article>
</div>

<div class="callout">
  <div class="section-kicker">PARTICIPER</div>
  <h2>Construisons ensemble les formations de demain.</h2>
  <p>Vous êtes enseignant, chercheur ou acteur de l'industrie logicielle ? Votre participation contribuera à forger les futures formations d'ingénieurs et d'informaticiens.</p>
  <a class="text-link" href="{{ '/organisation/' | relative_url }}">En savoir plus sur l'organisation →</a>
</div>
