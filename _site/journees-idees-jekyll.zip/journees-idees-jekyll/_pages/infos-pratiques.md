---
title: Informations & modalités
permalink: /infos-pratiques/
subtitle: Les informations pratiques seront complétées au fur et à mesure de leur confirmation.
---

## Lieu de la conférence

Le lieu exact de l'événement sera communiqué prochainement.

**Informations à venir.**

## Inscriptions

Les modalités d'inscription (académiques, industriels, doctorants) seront ouvertes sous peu.

**Ouverture prochaine.**

## Accès & hébergement

Des recommandations d'hôtels et les consignes d'accès en transports en commun seront mises à disposition.

**Informations à venir.**
