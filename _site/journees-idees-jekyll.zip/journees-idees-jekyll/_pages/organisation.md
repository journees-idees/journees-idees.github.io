---
title: Comité & organisation
permalink: /organisation/
subtitle: Participer aux Journées IDEES.
---

Vous souhaitez intervenir, proposer un retour d'expérience ou une démonstration ? Contactez l'équipe d'organisation.

Que vous soyez enseignant, chercheur ou acteur de l'industrie logicielle, votre participation contribuera à forger les futures formations d'ingénieurs et d'informaticiens.

Pour toute question, vous pouvez contacter l'équipe organisatrice.

- **Site officiel :** [journees-idees.github.io](https://journees-idees.github.io/)
- **Dépôt du projet :** [github.com/journees-idees/journees-idees.github.io](https://github.com/journees-idees/journees-idees.github.io)
