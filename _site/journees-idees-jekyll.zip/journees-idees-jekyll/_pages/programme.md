---
title: Programme prévisionnel
permalink: /programme/
subtitle: Deux journées d'ateliers, de retours d'expérience, de démonstrations et d'échanges.
---

Le programme est conçu pour alterner retours d'expérience, ateliers participatifs, démonstrations concrètes et moments conviviaux.

## Jeudi 17 décembre — Retours d'expérience & métiers de l'informatique

### Matin — Présentations d'industriels & déploiement de l'IA

Retours d'expérience sur le déploiement concret des technologies d'IA dans les entreprises.

- Technologies retenues
- Impacts sur l'organisation du travail
- Formation et accompagnement des juniors

Discussion collective avec l'auditoire.

### Midi — Buffet déjeunatoire

Déjeuner convivial sur place pour prolonger les échanges informels.

### Après-midi — Atelier « Informaticien versus Expert domaine »

Quelle est la place de l'informaticien à l'heure où l'expert domaine peut créer ses propres logiciels en étant assisté par l'IA ?

- Évolution des compétences
- Ingénierie logicielle vs bricolage assisté

### Soirée — Dîner des journées

Dîner au restaurant L'Inattendu avec l'ensemble des participants.

## Vendredi 18 décembre — Outils, concepts & démonstrations

### Matin — Atelier « IA pour le développement & développement pour l'IA »

Quels sont les outils et concepts à connaître et à savoir mettre en œuvre autour de l'IA ?

Que faut-il savoir utiliser ? Que faut-il savoir développer ?

**Harnais · Skills & Tools · Spec-Driven Dev · MCP · A2A · LLM / SLM · RAG · Agents**

### Midi — Buffet déjeunatoire

Repas convivial sur place.

### Après-midi — Démonstrations industrielles & clôture

Démonstrations en direct par des partenaires industriels des systèmes et architectures qu'ils utilisent en production.

Conclusions et perspectives : synthèse des recommandations pour les formations en informatique.
